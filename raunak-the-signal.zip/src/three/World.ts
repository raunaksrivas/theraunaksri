/* ============================================================
   WORLD.TS · One continuous WebGL world behind the story.
   The camera travels a single corridor in z. Each chapter is a
   physical place along the corridor; scroll position is the
   only timeline. No postprocessing, no lights: everything is
   additive glow, instancing, and small custom shaders, so the
   whole world stays cheap enough for mobile GPUs.
   ============================================================ */

import * as THREE from 'three';

export interface WorldHandles {
  setProgress(p: number): void;
  setPointer(x: number, y: number): void;
  setWaypoint(i: number): void;
  setRing(i: number): void;
  start(): void;
  stop(): void;
  renderOnce(atProgress?: number): void;
  dispose(): void;
}

type Quality = 'hi' | 'lo';

const CAM_START = 6;
const CAM_END = -258;

/* Chapter zones expressed in global progress (0..1). These match
   the HTML pacing in App.tsx: keep them in sync if sections move. */
const ZONE = {
  ch1: { a: 0.0, b: 0.18 },
  ch2: { a: 0.18, b: 0.42 },
  ch3: { a: 0.42, b: 0.64 },
  ch4: { a: 0.64, b: 0.82 },
  ch5: { a: 0.82, b: 1.0 },
};

const clamp01 = (v: number) => Math.min(1, Math.max(0, v));
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const span = (p: number, a: number, b: number) => clamp01((p - a) / (b - a));
const ease = (t: number) => t * t * (3 - 2 * t);

/* ---------- soft glow texture (shared) ---------- */
function makeGlowTexture(): THREE.Texture {
  const size = 128;
  const c = document.createElement('canvas');
  c.width = c.height = size;
  const ctx = c.getContext('2d')!;
  const g = ctx.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
  g.addColorStop(0, 'rgba(255,255,255,1)');
  g.addColorStop(0.25, 'rgba(255,255,255,0.55)');
  g.addColorStop(0.6, 'rgba(255,255,255,0.12)');
  g.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, size, size);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

/* ---------- drifting / rising particle field ---------- */
interface FieldOpts {
  count: number;
  box: { x: number; y: number; z: [number, number] };
  size: number;
  colors: THREE.Color[];
  drift: number;
  rise?: number; // units per second upward, wrapped
  opacity: number;
  near?: number;
  far?: number;
}

function makeField(glow: THREE.Texture, o: FieldOpts) {
  const pos = new Float32Array(o.count * 3);
  const seed = new Float32Array(o.count * 3);
  const col = new Float32Array(o.count * 3);
  const siz = new Float32Array(o.count);

  for (let i = 0; i < o.count; i++) {
    pos[i * 3] = (Math.random() * 2 - 1) * o.box.x;
    pos[i * 3 + 1] = (Math.random() * 2 - 1) * o.box.y;
    pos[i * 3 + 2] = lerp(o.box.z[0], o.box.z[1], Math.random());
    seed[i * 3] = Math.random() * Math.PI * 2; // phase
    seed[i * 3 + 1] = 0.25 + Math.random() * 0.8; // speed
    seed[i * 3 + 2] = 0.4 + Math.random() * 1.0; // amp scale
    const c = o.colors[(Math.random() * o.colors.length) | 0];
    col[i * 3] = c.r;
    col[i * 3 + 1] = c.g;
    col[i * 3 + 2] = c.b;
    siz[i] = 0.6 + Math.random() * 1.1;
  }

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  geo.setAttribute('aSeed', new THREE.BufferAttribute(seed, 3));
  geo.setAttribute('aColor', new THREE.BufferAttribute(col, 3));
  geo.setAttribute('aSize', new THREE.BufferAttribute(siz, 1));

  const mat = new THREE.ShaderMaterial({
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    uniforms: {
      uTime: { value: 0 },
      uPR: { value: 1 },
      uSize: { value: o.size },
      uDrift: { value: o.drift },
      uRise: { value: o.rise ?? 0 },
      uYRange: { value: o.box.y * 2 },
      uOpacity: { value: o.opacity },
      uNear: { value: o.near ?? 3 },
      uFar: { value: o.far ?? 46 },
      uMap: { value: glow },
    },
    vertexShader: /* glsl */ `
      attribute vec3 aSeed;
      attribute vec3 aColor;
      attribute float aSize;
      uniform float uTime, uPR, uSize, uDrift, uRise, uYRange, uNear, uFar;
      varying vec3 vColor;
      varying float vFade;
      void main() {
        vColor = aColor;
        vec3 p = position;
        float t = uTime * aSeed.y;
        p.x += sin(t + aSeed.x) * uDrift * aSeed.z;
        p.y += cos(t * 0.83 + aSeed.x * 1.7) * uDrift * 0.7 * aSeed.z;
        if (uRise > 0.0) {
          float travelled = position.y + uTime * uRise * aSeed.y;
          p.y = mod(travelled + uYRange * 0.5, uYRange) - uYRange * 0.5;
        }
        vec4 mv = modelViewMatrix * vec4(p, 1.0);
        float depth = -mv.z;
        vFade = smoothstep(uFar, uNear, depth) * smoothstep(0.0, 2.0, depth);
        gl_PointSize = uSize * aSize * uPR * (220.0 / max(depth, 0.001));
        gl_Position = projectionMatrix * mv;
      }
    `,
    fragmentShader: /* glsl */ `
      uniform float uOpacity;
      uniform sampler2D uMap;
      varying vec3 vColor;
      varying float vFade;
      void main() {
        float a = texture2D(uMap, gl_PointCoord).r;
        gl_FragColor = vec4(vColor, a * uOpacity * vFade);
        if (gl_FragColor.a < 0.003) discard;
      }
    `,
  });

  return new THREE.Points(geo, mat);
}

function glowSprite(glow: THREE.Texture, color: number, scale: number, opacity: number) {
  const m = new THREE.SpriteMaterial({
    map: glow,
    color,
    transparent: true,
    opacity,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
  });
  const s = new THREE.Sprite(m);
  s.scale.setScalar(scale);
  return s;
}

/* ============================================================ */

export function createWorld(canvas: HTMLCanvasElement, quality: Quality): WorldHandles {
  const hi = quality === 'hi';

  const renderer = new THREE.WebGLRenderer({
    canvas,
    antialias: hi,
    alpha: false,
    powerPreference: 'high-performance',
  });
  const maxPR = hi ? 1.75 : 1.4;
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, maxPR));
  renderer.setSize(window.innerWidth, window.innerHeight, false);

  const scene = new THREE.Scene();
  const bg = new THREE.Color('#070203');
  scene.background = bg;
  scene.fog = new THREE.FogExp2('#070203', 0.05);

  const camera = new THREE.PerspectiveCamera(58, window.innerWidth / window.innerHeight, 0.1, 120);
  camera.position.set(0, 0, CAM_START);

  const glow = makeGlowTexture();

  /* Color script: cinematic grading keyed to progress. */
  const GRADE: { p: number; c: THREE.Color }[] = [
    { p: 0.0, c: new THREE.Color('#070203') },
    { p: 0.14, c: new THREE.Color('#100305') },
    { p: 0.3, c: new THREE.Color('#06141b') },
    { p: 0.46, c: new THREE.Color('#0c0a0f') },
    { p: 0.62, c: new THREE.Color('#0b0a0c') },
    { p: 0.74, c: new THREE.Color('#061214') },
    { p: 0.86, c: new THREE.Color('#140506') },
    { p: 1.0, c: new THREE.Color('#1f0807') },
  ];
  const gradeAt = (p: number, out: THREE.Color) => {
    for (let i = 0; i < GRADE.length - 1; i++) {
      const a = GRADE[i];
      const b = GRADE[i + 1];
      if (p <= b.p) {
        out.copy(a.c).lerp(b.c, span(p, a.p, b.p));
        return;
      }
    }
    out.copy(GRADE[GRADE.length - 1].c);
  };

  const disposables: { dispose(): void }[] = [];
  const track = <T extends { dispose(): void }>(d: T): T => {
    disposables.push(d);
    return d;
  };
  const sprite = (color: number, scale: number, opacity: number) => {
    const s = glowSprite(glow, color, scale, opacity);
    track(s.material);
    return s;
  };

  /* ------------------------------------------------------------------
     SHARED · corridor dust, gives continuity from first frame to last
  ------------------------------------------------------------------ */
  const dust = makeField(glow, {
    count: hi ? 1700 : 750,
    box: { x: 34, y: 20, z: [16, -272] },
    size: 0.9,
    colors: [new THREE.Color('#7a5050'), new THREE.Color('#6e3434'), new THREE.Color('#4d4a52')],
    drift: 0.7,
    opacity: 0.5,
    far: 52,
  });
  scene.add(dust);

  /* ------------------------------------------------------------------
     CH.01 · THE SIGNAL · ember idea field, orbiting thought orbs
  ------------------------------------------------------------------ */
  const ch1 = new THREE.Group();
  scene.add(ch1);

  const ideaField = makeField(glow, {
    count: hi ? 2300 : 1000,
    box: { x: 24, y: 13, z: [12, -40] },
    size: 1.5,
    colors: [new THREE.Color('#ff4d4d'), new THREE.Color('#e53935'), new THREE.Color('#ff8a50'), new THREE.Color('#ffd2c2')],
    drift: 1.5,
    opacity: 0.85,
    far: 44,
  });
  ch1.add(ideaField);

  const rings: THREE.Mesh[] = [];
  const ringMat = track(
    new THREE.MeshBasicMaterial({ color: '#e53935', transparent: true, opacity: 0.2, fog: true }),
  );
  [3.4, 4.8, 6.4].forEach((r, i) => {
    const ring = new THREE.Mesh(track(new THREE.TorusGeometry(r, 0.012, 8, 120)), ringMat);
    ring.position.set(0, 0.4, -8);
    ring.rotation.x = 0.5 + i * 0.18;
    ring.rotation.y = i * 0.35;
    rings.push(ring);
    ch1.add(ring);
  });

  interface Orb {
    g: THREE.Group;
    base: THREE.Vector3;
    r: number;
    sp: number;
    off: number;
    halo: THREE.Sprite;
    shell: THREE.Mesh;
  }
  const orbs: Orb[] = [];
  const orbShellGeo = track(new THREE.IcosahedronGeometry(0.5, 0));
  [
    new THREE.Vector3(-5.5, 2.0, -10),
    new THREE.Vector3(6.2, -1.6, -14),
    new THREE.Vector3(1.2, 3.4, -20),
  ].forEach((base, i) => {
    const g = new THREE.Group();
    const halo = sprite(0xff4d4d, 3.4, 0.65);
    const shell = new THREE.Mesh(
      orbShellGeo,
      track(new THREE.MeshBasicMaterial({ color: '#ff7a6a', wireframe: true, transparent: true, opacity: 0.55 })),
    );
    g.add(halo, shell);
    g.position.copy(base);
    ch1.add(g);
    orbs.push({ g, base, r: 0.9 + i * 0.3, sp: 0.3 + i * 0.12, off: i * 2.1, halo, shell });
  });

  /* ------------------------------------------------------------------
     CH.02 · THE CIRCUIT · manhattan trace with seven stations
  ------------------------------------------------------------------ */
  const ch2 = new THREE.Group();
  scene.add(ch2);

  const STATION_COUNT = 7;
  const stationPts: THREE.Vector3[] = [];
  for (let i = 0; i < STATION_COUNT; i++) {
    const x = (i % 2 === 0 ? -5.6 : 5.6) + Math.sin(i * 2.3) * 0.8;
    const y = Math.sin(i * 1.7) * 1.8 - 0.4;
    const z = -52 - i * 7;
    stationPts.push(new THREE.Vector3(x, y, z));
  }

  /* Build an axis aligned path: z run, then x jog, then y jog. */
  const pathPts: THREE.Vector3[] = [new THREE.Vector3(-2.5, -3.2, -45)];
  const stationVertIndex: number[] = [];
  for (let i = 0; i < STATION_COUNT; i++) {
    const prev = pathPts[pathPts.length - 1];
    const s = stationPts[i];
    const zMid = s.z + 3;
    pathPts.push(new THREE.Vector3(prev.x, prev.y, zMid));
    pathPts.push(new THREE.Vector3(s.x, prev.y, zMid));
    pathPts.push(new THREE.Vector3(s.x, s.y, zMid));
    pathPts.push(new THREE.Vector3(s.x, s.y, s.z));
    stationVertIndex.push(pathPts.length - 1);
  }
  /* tail out of the chapter */
  const last = pathPts[pathPts.length - 1];
  pathPts.push(new THREE.Vector3(last.x, last.y, last.z - 6));
  pathPts.push(new THREE.Vector3(0, -1.5, last.z - 10));

  const segLen: number[] = [0];
  for (let i = 1; i < pathPts.length; i++) {
    segLen.push(segLen[i - 1] + pathPts[i].distanceTo(pathPts[i - 1]));
  }
  const totalLen = segLen[segLen.length - 1];
  const samplePath = (fr: number, out: THREE.Vector3) => {
    const target = clamp01(fr) * totalLen;
    for (let i = 1; i < segLen.length; i++) {
      if (segLen[i] >= target) {
        const t = (target - segLen[i - 1]) / Math.max(segLen[i] - segLen[i - 1], 1e-5);
        out.copy(pathPts[i - 1]).lerp(pathPts[i], t);
        return;
      }
    }
    out.copy(pathPts[pathPts.length - 1]);
  };

  const traceGeo = track(new THREE.BufferGeometry().setFromPoints(pathPts));
  const traceBase = new THREE.Line(
    traceGeo,
    track(new THREE.LineBasicMaterial({ color: '#54181c', transparent: true, opacity: 0.85, fog: true })),
  );
  const traceLive = new THREE.Line(
    traceGeo,
    track(
      new THREE.LineBasicMaterial({
        color: '#ff4d4d',
        transparent: true,
        opacity: 0.95,
        fog: false,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      }),
    ),
  );
  traceLive.geometry = traceGeo; // shared, drawRange controls energized length
  ch2.add(traceBase, traceLive);

  interface StationNode {
    ring: THREE.Mesh;
    halo: THREE.Sprite;
    dot: THREE.Mesh;
    mat: THREE.MeshBasicMaterial;
  }
  const stationNodes: StationNode[] = [];
  const stRingGeo = track(new THREE.TorusGeometry(0.78, 0.028, 8, 48));
  const stDotGeo = track(new THREE.SphereGeometry(0.09, 12, 12));
  stationPts.forEach((p) => {
    const mat = track(
      new THREE.MeshBasicMaterial({ color: '#e53935', transparent: true, opacity: 0.3, fog: true }),
    );
    const ring = new THREE.Mesh(stRingGeo, mat);
    ring.position.copy(p);
    const halo = sprite(0xff4d4d, 2.4, 0);
    halo.position.copy(p);
    const dot = new THREE.Mesh(stDotGeo, mat);
    dot.position.copy(p);
    ch2.add(ring, halo, dot);
    stationNodes.push({ ring, halo, dot, mat });
  });

  const pulse = sprite(0xffd9c4, 1.5, 0.95);
  const pulseCore = sprite(0xff4d4d, 0.7, 1);
  ch2.add(pulse, pulseCore);

  /* ------------------------------------------------------------------
     CH.03 · THE PAYLOAD · artifact monoliths, data skyline, gridfloor
  ------------------------------------------------------------------ */
  const ch3 = new THREE.Group();
  scene.add(ch3);

  const floorMat = track(
    new THREE.ShaderMaterial({
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      uniforms: {
        uTime: { value: 0 },
        uColor: { value: new THREE.Color('#e53935') },
        uEmber: { value: new THREE.Color('#ff8a50') },
      },
      vertexShader: /* glsl */ `
        varying vec2 vUv;
        void main() {
          vUv = uv;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: /* glsl */ `
        uniform float uTime;
        uniform vec3 uColor, uEmber;
        varying vec2 vUv;
        void main() {
          vec2 cells = vUv * vec2(34.0, 60.0);
          vec2 g = abs(fract(cells) - 0.5);
          float line = smoothstep(0.5, 0.47, max(g.x, g.y));
          float dz = abs(vUv.y - 0.5);
          float dx = abs(vUv.x - 0.5);
          float fade = smoothstep(0.5, 0.08, dz) * smoothstep(0.5, 0.1, dx);
          float sweep = smoothstep(0.06, 0.0, abs(fract(vUv.y * 6.0 - uTime * 0.12) - 0.5) - 0.44);
          vec3 col = uColor * 0.55 + uEmber * sweep * 1.4;
          gl_FragColor = vec4(col, line * fade * (0.16 + sweep * 0.5));
        }
      `,
    }),
  );
  const floor = new THREE.Mesh(track(new THREE.PlaneGeometry(70, 130)), floorMat);
  floor.rotation.x = -Math.PI / 2;
  floor.position.set(0, -5, -132);
  ch3.add(floor);

  interface Monolith {
    g: THREE.Group;
    sp: number;
    off: number;
  }
  const monoliths: Monolith[] = [];
  const monoCount = hi ? 6 : 4;
  const monoBox = track(new THREE.BoxGeometry(2.2, 4.4, 0.5));
  const monoEdges = track(new THREE.EdgesGeometry(monoBox));
  const monoFaceGeo = track(new THREE.PlaneGeometry(2.2, 4.4));
  for (let i = 0; i < monoCount; i++) {
    const g = new THREE.Group();
    const edge = new THREE.LineSegments(
      monoEdges,
      track(new THREE.LineBasicMaterial({ color: '#ff5a4d', transparent: true, opacity: 0.8, fog: true })),
    );
    const face = new THREE.Mesh(
      monoFaceGeo,
      track(new THREE.MeshBasicMaterial({ color: '#130507', transparent: true, opacity: 0.94, fog: true })),
    );
    face.position.z = 0.26;
    const back = face.clone();
    back.position.z = -0.26;
    back.rotation.y = Math.PI;
    const crown = sprite(0xff8a50, 1.6, 0.5);
    crown.position.y = 2.6;
    g.add(edge, face, back, crown);
    const side = i % 2 === 0 ? -1 : 1;
    g.position.set(side * (4.6 + (i % 3) * 2.6), -1.2 + Math.sin(i * 2.1) * 0.8, -116 - i * 6.5);
    g.rotation.y = side * 0.35 + i * 0.12;
    ch3.add(g);
    monoliths.push({ g, sp: 0.12 + (i % 3) * 0.05, off: i * 1.7 });
  }

  const BAR_COUNT = hi ? 26 : 14;
  const barGeo = track(new THREE.BoxGeometry(0.4, 1, 0.4));
  const barMat = track(
    new THREE.MeshBasicMaterial({ color: '#e53935', transparent: true, opacity: 0.65, fog: true }),
  );
  const bars = new THREE.InstancedMesh(barGeo, barMat, BAR_COUNT);
  bars.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
  ch3.add(bars);
  const barDummy = new THREE.Object3D();

  /* ------------------------------------------------------------------
     CH.04 · THE ENGINE · gyroscopic skill constellation
  ------------------------------------------------------------------ */
  const ch4 = new THREE.Group();
  ch4.position.set(0, 0.4, -188);
  scene.add(ch4);

  const core = new THREE.Mesh(
    track(new THREE.IcosahedronGeometry(1.0, 1)),
    track(new THREE.MeshBasicMaterial({ color: '#ff4d4d', wireframe: true, transparent: true, opacity: 0.9 })),
  );
  const coreHalo = sprite(0xe53935, 5.5, 0.5);
  ch4.add(core, coreHalo);

  interface Ring {
    group: THREE.Group;
    nodes: THREE.InstancedMesh;
    loop: THREE.LineLoop;
    guide: THREE.Mesh;
    nodeMat: THREE.MeshBasicMaterial;
    loopMat: THREE.LineBasicMaterial;
    guideMat: THREE.MeshBasicMaterial;
    count: number;
    radius: number;
    speed: number;
    active: number;
  }
  const RING_COUNTS = [11, 12, 13, 9];
  const ringObjs: Ring[] = [];
  const nodeGeo = track(new THREE.SphereGeometry(0.085, 10, 10));
  RING_COUNTS.forEach((count, i) => {
    const radius = 2.5 + i * 1.18;
    const group = new THREE.Group();
    group.rotation.x = [0.45, -0.6, 1.05, 0.15][i];
    group.rotation.z = [0.2, -0.35, 0.5, -0.15][i];

    const nodeMat = track(
      new THREE.MeshBasicMaterial({ color: '#b03430', transparent: true, opacity: 0.95 }),
    );
    const nodes = new THREE.InstancedMesh(nodeGeo, nodeMat, count);
    nodes.instanceMatrix.setUsage(THREE.DynamicDrawUsage);

    const loopPts: THREE.Vector3[] = [];
    for (let k = 0; k < count; k++) {
      const a = (k / count) * Math.PI * 2;
      loopPts.push(new THREE.Vector3(Math.cos(a) * radius, Math.sin(a) * radius, 0));
    }
    const loopMat = track(
      new THREE.LineBasicMaterial({ color: '#e53935', transparent: true, opacity: 0.1 }),
    );
    const loop = new THREE.LineLoop(track(new THREE.BufferGeometry().setFromPoints(loopPts)), loopMat);

    const guideMat = track(
      new THREE.MeshBasicMaterial({ color: '#e53935', transparent: true, opacity: 0.1 }),
    );
    const guide = new THREE.Mesh(track(new THREE.TorusGeometry(radius, 0.012, 6, 90)), guideMat);

    group.add(nodes, loop, guide);
    ch4.add(group);
    ringObjs.push({
      group,
      nodes,
      loop,
      guide,
      nodeMat,
      loopMat,
      guideMat,
      count,
      radius,
      speed: (0.16 + i * 0.05) * (i % 2 === 0 ? 1 : -1),
      active: 0,
    });
  });
  const nodeDummy = new THREE.Object3D();
  const NODE_BASE = new THREE.Color('#b03430');
  const NODE_HOT = new THREE.Color('#ff6b5e');

  /* ------------------------------------------------------------------
     CH.05 · THE HORIZON · rising signal sun, ascending sparks
  ------------------------------------------------------------------ */
  const ch5 = new THREE.Group();
  scene.add(ch5);

  const sunMat = track(
    new THREE.ShaderMaterial({
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      uniforms: {
        uTime: { value: 0 },
        uCore: { value: new THREE.Color('#ffb27a') },
        uEdge: { value: new THREE.Color('#e53935') },
        uReveal: { value: 0 },
      },
      vertexShader: /* glsl */ `
        varying vec2 vUv;
        void main() {
          vUv = uv;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: /* glsl */ `
        uniform float uTime, uReveal;
        uniform vec3 uCore, uEdge;
        varying vec2 vUv;
        void main() {
          vec2 d = vUv - 0.5;
          float r = length(d) * 2.0;
          float disc = smoothstep(1.0, 0.96, r);
          float grade = smoothstep(1.0, 0.0, r);
          vec3 col = mix(uEdge, uCore, grade * grade);
          float lower = smoothstep(0.52, 0.38, vUv.y);
          float bands = smoothstep(0.32, 0.5, abs(fract(vUv.y * 15.0 - uTime * 0.25) - 0.5));
          float slit = mix(1.0, bands, lower);
          float a = disc * slit * (0.32 + 0.68 * grade) * uReveal;
          gl_FragColor = vec4(col * (0.7 + 0.5 * grade), a);
        }
      `,
    }),
  );
  const sun = new THREE.Mesh(track(new THREE.CircleGeometry(7.6, 72)), sunMat);
  sun.position.set(0, -6, -250);
  ch5.add(sun);

  const sunBack = sprite(0xff5a3c, 34, 0.0);
  sunBack.position.set(0, -2, -252.5);
  const hazeL = sprite(0xe53935, 1, 0.0);
  hazeL.scale.set(48, 7, 1);
  hazeL.position.set(0, -5.2, -247);
  ch5.add(sunBack, hazeL);

  const sparks = makeField(glow, {
    count: hi ? 650 : 320,
    box: { x: 17, y: 11, z: [-234, -260] },
    size: 1.2,
    colors: [new THREE.Color('#ff8a50'), new THREE.Color('#ff4d4d'), new THREE.Color('#ffd2a8')],
    drift: 0.5,
    rise: 0.75,
    opacity: 0.0,
    far: 50,
  });
  sparks.position.y = -1;
  ch5.add(sparks);

  /* ------------------------------------------------------------------
     state + loop
  ------------------------------------------------------------------ */
  let progress = 0;
  let pointerX = 0;
  let pointerY = 0;
  let camX = 0;
  let camY = 0;
  let waypoint = -1;
  let activeRing = -1;
  let raf = 0;
  let running = false;
  const clock = new THREE.Clock();
  let elapsed = 0;
  const tmpVec = new THREE.Vector3();
  const tmpCol = new THREE.Color();

  function setVisibility() {
    const camZ = camera.position.z;
    ch1.visible = camZ > -52;
    ch2.visible = camZ < -28 && camZ > -118;
    ch3.visible = camZ < -90 && camZ > -172;
    ch4.visible = camZ < -150 && camZ > -228;
    ch5.visible = camZ < -206;
  }

  function update(dt: number) {
    elapsed += dt;
    const t = elapsed;
    const p = progress;

    /* camera */
    const camZ = lerp(CAM_START, CAM_END, p);
    camX += (pointerX * 0.7 - camX) * 0.04;
    camY += (pointerY * 0.45 - camY) * 0.04;
    camera.position.set(camX, camY, camZ);
    camera.lookAt(camX * 0.35, camY * 0.3, camZ - 12);

    /* grading */
    gradeAt(p, tmpCol);
    bg.copy(tmpCol);
    (scene.fog as THREE.FogExp2).color.copy(tmpCol);

    setVisibility();

    /* dust */
    (dust.material as THREE.ShaderMaterial).uniforms.uTime.value = t;

    /* CH1 */
    if (ch1.visible) {
      (ideaField.material as THREE.ShaderMaterial).uniforms.uTime.value = t;
      const local = span(p, ZONE.ch1.a, ZONE.ch1.b);
      rings.forEach((r, i) => {
        r.rotation.z += dt * (0.05 + i * 0.025);
        r.rotation.y += dt * 0.03;
      });
      ringMat.opacity = 0.22 * (1 - local * 0.6);
      orbs.forEach((o) => {
        const a = t * o.sp + o.off;
        o.g.position.set(
          o.base.x + Math.cos(a) * o.r,
          o.base.y + Math.sin(a * 0.8) * o.r * 0.5,
          o.base.z + Math.sin(a * 0.6) * 0.8,
        );
        o.shell.rotation.x += dt * 0.4;
        o.shell.rotation.y += dt * 0.55;
        const pulseS = 1 + Math.sin(t * 1.6 + o.off) * 0.12;
        o.halo.scale.setScalar(3.4 * pulseS);
      });
    }

    /* CH2 */
    if (ch2.visible) {
      const f = span(camera.position.z, -48, -94) /* 0..1 along stations by camera depth */;
      const stationF = f * (STATION_COUNT - 1);

      /* energized trace length */
      const idxA = Math.floor(stationF);
      const idxB = Math.min(idxA + 1, STATION_COUNT - 1);
      const vA = idxA <= 0 ? 0 : stationVertIndex[idxA];
      const vB = stationVertIndex[idxB];
      const liveCount = Math.round(lerp(vA, vB, stationF - idxA)) + 1;
      traceGeo.setDrawRange(0, Math.max(2, liveCount));

      /* pulse rides the head of the energized portion */
      samplePath((segLen[Math.min(segLen.length - 1, Math.max(1, liveCount - 1))] ?? 0) / totalLen, tmpVec);
      pulse.position.copy(tmpVec);
      pulseCore.position.copy(tmpVec);
      const flick = 0.85 + Math.sin(t * 9) * 0.15;
      (pulse.material as THREE.SpriteMaterial).opacity = 0.9 * flick;
      pulse.scale.setScalar(1.4 + Math.sin(t * 5) * 0.18);

      stationNodes.forEach((s, i) => {
        const isActive = i === waypoint;
        const passed = stationF >= i - 0.05;
        const targetOp = isActive ? 0.95 : passed ? 0.55 : 0.22;
        s.mat.opacity += (targetOp - s.mat.opacity) * 0.08;
        const targetHalo = isActive ? 0.85 : passed ? 0.18 : 0;
        const hm = s.halo.material as THREE.SpriteMaterial;
        hm.opacity += (targetHalo - hm.opacity) * 0.08;
        const targetScale = isActive ? 1.35 : 1;
        const cs = s.ring.scale.x + (targetScale - s.ring.scale.x) * 0.08;
        s.ring.scale.setScalar(cs);
        s.ring.rotation.z += dt * (isActive ? 0.8 : 0.15);
        s.mat.color.lerp(isActive ? NODE_HOT : new THREE.Color('#e53935'), 0.1);
      });
    }

    /* CH3 */
    if (ch3.visible) {
      floorMat.uniforms.uTime.value = t;
      const local = span(p, ZONE.ch3.a, ZONE.ch3.b);
      monoliths.forEach((m) => {
        m.g.rotation.y += dt * m.sp;
        m.g.position.y += Math.sin(t * 0.7 + m.off) * 0.0016;
      });
      const rise = ease(span(local, 0.08, 0.5));
      for (let i = 0; i < BAR_COUNT; i++) {
        const wave = (Math.sin(t * 1.4 + i * 0.62) * 0.5 + 0.5) ** 1.4;
        const h = (0.5 + wave * 2.8) * (0.15 + rise * 0.85);
        barDummy.position.set(-((BAR_COUNT - 1) * 0.62) / 2 + i * 0.62, -5 + h / 2, -150.5);
        barDummy.scale.set(1, h, 1);
        barDummy.updateMatrix();
        bars.setMatrixAt(i, barDummy.matrix);
      }
      bars.instanceMatrix.needsUpdate = true;
    }

    /* CH4 */
    if (ch4.visible) {
      core.rotation.y += dt * 0.35;
      core.rotation.x += dt * 0.18;
      const breath = 1 + Math.sin(t * 1.8) * 0.06;
      core.scale.setScalar(breath);
      coreHalo.scale.setScalar(5.5 * breath);
      ringObjs.forEach((r, ri) => {
        r.group.rotation.y += dt * r.speed;
        const targetActive = activeRing === ri ? 1 : activeRing === -1 ? 0.25 : 0;
        r.active += (targetActive - r.active) * 0.07;
        r.nodeMat.color.copy(NODE_BASE).lerp(NODE_HOT, r.active);
        r.loopMat.opacity = 0.08 + r.active * 0.3;
        r.guideMat.opacity = 0.08 + r.active * 0.25;
        for (let k = 0; k < r.count; k++) {
          const a = (k / r.count) * Math.PI * 2 + t * 0.05;
          const s = 1 + r.active * 0.85 + Math.sin(t * 3 + k) * 0.1 * r.active;
          nodeDummy.position.set(Math.cos(a) * r.radius, Math.sin(a) * r.radius, Math.sin(t * 0.9 + k) * 0.12);
          nodeDummy.scale.setScalar(s);
          nodeDummy.updateMatrix();
          r.nodes.setMatrixAt(k, nodeDummy.matrix);
        }
        r.nodes.instanceMatrix.needsUpdate = true;
      });
    }

    /* CH5 */
    if (ch5.visible) {
      sunMat.uniforms.uTime.value = t;
      const local = span(p, ZONE.ch5.a, 0.99);
      const rise = ease(span(local, 0.18, 0.85));
      sunMat.uniforms.uReveal.value = rise;
      sun.position.y = lerp(-6.5, 1.6, rise);
      (sunBack.material as THREE.SpriteMaterial).opacity = 0.34 * rise;
      (hazeL.material as THREE.SpriteMaterial).opacity = 0.3 * rise;
      (sparks.material as THREE.ShaderMaterial).uniforms.uTime.value = t;
      (sparks.material as THREE.ShaderMaterial).uniforms.uOpacity.value = 0.8 * ease(span(local, 0.05, 0.5));
    }
  }

  /* The base trace needs its own geometry so drawRange on the live
     copy never truncates it. */
  const baseGeoCopy = track(traceGeo.clone());
  traceBase.geometry = baseGeoCopy;

  function frame() {
    if (!running) return;
    const dt = Math.min(clock.getDelta(), 0.05);
    update(dt);
    renderer.render(scene, camera);
    raf = requestAnimationFrame(frame);
  }

  function onResize() {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight, false);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, maxPR));
  }
  window.addEventListener('resize', onResize);

  function onVisibility() {
    if (document.hidden) {
      if (running) {
        cancelAnimationFrame(raf);
        running = false;
        (onVisibility as { resume?: boolean }).resume = true;
      }
    } else if ((onVisibility as { resume?: boolean }).resume) {
      (onVisibility as { resume?: boolean }).resume = false;
      running = true;
      clock.getDelta();
      raf = requestAnimationFrame(frame);
    }
  }
  document.addEventListener('visibilitychange', onVisibility);

  /* set uPR on all shader fields */
  const pr = renderer.getPixelRatio();
  [dust, ideaField, sparks].forEach((f) => {
    (f.material as THREE.ShaderMaterial).uniforms.uPR.value = pr;
  });

  return {
    setProgress(p) {
      progress = clamp01(p);
    },
    setPointer(x, y) {
      pointerX = x;
      pointerY = y;
    },
    setWaypoint(i) {
      waypoint = i;
    },
    setRing(i) {
      activeRing = i;
    },
    start() {
      if (running) return;
      running = true;
      clock.getDelta();
      raf = requestAnimationFrame(frame);
    },
    stop() {
      running = false;
      cancelAnimationFrame(raf);
    },
    renderOnce(atProgress = 0.06) {
      progress = atProgress;
      update(1 / 60);
      renderer.render(scene, camera);
    },
    dispose() {
      running = false;
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', onResize);
      document.removeEventListener('visibilitychange', onVisibility);
      disposables.forEach((d) => d.dispose());
      glow.dispose();
      renderer.dispose();
    },
  };
}
