import { useEffect, useRef, useState } from 'react';

/* Smoothed scroll progress (0..1) across the whole document.
   Reads on rAF only, never inside the scroll handler. */
export function useScrollProgress(onProgress: (p: number) => void) {
  const cb = useRef(onProgress);
  cb.current = onProgress;

  useEffect(() => {
    let raw = 0;
    let eased = 0;
    let raf = 0;
    let running = true;

    const read = () => {
      const max = document.documentElement.scrollHeight - window.innerHeight;
      raw = max > 0 ? Math.min(1, Math.max(0, window.scrollY / max)) : 0;
    };

    const loop = () => {
      if (!running) return;
      eased += (raw - eased) * 0.085;
      if (Math.abs(raw - eased) < 0.0004) eased = raw;
      cb.current(eased);
      raf = requestAnimationFrame(loop);
    };

    read();
    eased = raw;
    window.addEventListener('scroll', read, { passive: true });
    window.addEventListener('resize', read);
    raf = requestAnimationFrame(loop);

    return () => {
      running = false;
      cancelAnimationFrame(raf);
      window.removeEventListener('scroll', read);
      window.removeEventListener('resize', read);
    };
  }, []);
}

/* Adds an `in` class when the element enters the viewport. One way. */
export function useReveal<T extends HTMLElement>(threshold = 0.18) {
  const ref = useRef<T | null>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (typeof IntersectionObserver === 'undefined') {
      el.classList.add('in');
      return;
    }
    const io = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          el.classList.add('in');
          io.disconnect();
        }
      },
      { threshold, rootMargin: '0px 0px -8% 0px' },
    );
    io.observe(el);
    return () => io.disconnect();
  }, [threshold]);
  return ref;
}

/* Tracks which of a set of sections is currently most in view. */
export function useActiveSection(ids: string[]) {
  const [active, setActive] = useState(ids[0]);
  useEffect(() => {
    if (typeof IntersectionObserver === 'undefined') return;
    const ratios = new Map<string, number>();
    const io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) ratios.set((e.target as HTMLElement).id, e.intersectionRatio);
        let best = active;
        let bestRatio = -1;
        for (const id of ids) {
          const r = ratios.get(id) ?? 0;
          if (r > bestRatio) {
            bestRatio = r;
            best = id;
          }
        }
        if (bestRatio > 0) setActive(best);
      },
      { threshold: [0, 0.12, 0.3, 0.55, 0.8] },
    );
    ids.forEach((id) => {
      const el = document.getElementById(id);
      if (el) io.observe(el);
    });
    return () => io.disconnect();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ids.join('|')]);
  return active;
}

export function usePrefersReducedMotion() {
  const [reduced, setReduced] = useState(
    () => typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches,
  );
  useEffect(() => {
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    const fn = () => setReduced(mq.matches);
    mq.addEventListener('change', fn);
    return () => mq.removeEventListener('change', fn);
  }, []);
  return reduced;
}

/* Crude but honest device quality heuristic. */
export function detectQuality(): 'hi' | 'lo' {
  if (typeof window === 'undefined') return 'lo';
  const nav = navigator as Navigator & { deviceMemory?: number };
  const smallScreen = window.innerWidth < 860;
  const lowMem = (nav.deviceMemory ?? 8) <= 4;
  const lowCpu = (navigator.hardwareConcurrency ?? 8) <= 4;
  return smallScreen || lowMem || lowCpu ? 'lo' : 'hi';
}

export const clamp01 = (v: number) => Math.min(1, Math.max(0, v));
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
/* Maps progress p into a local 0..1 inside [a,b]. */
export const span = (p: number, a: number, b: number) => clamp01((p - a) / (b - a));
