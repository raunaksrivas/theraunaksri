import { useCallback, useEffect, useRef, useState } from 'react';
import {
  detectQuality,
  useActiveSection,
  usePrefersReducedMotion,
  useScrollProgress,
} from '@/lib/hooks';
import type { WorldHandles } from '@/three/World';
import Boot from '@/components/Boot';
import TopBar from '@/components/TopBar';
import RailNav from '@/components/RailNav';
import IndexOverlay from '@/components/IndexOverlay';
import Ch1 from '@/components/Ch1';
import Ch2 from '@/components/Ch2';
import Ch3 from '@/components/Ch3';
import Ch4 from '@/components/Ch4';
import Echoes from '@/components/Echoes';
import Ch5 from '@/components/Ch5';

const SECTION_IDS = ['ch1', 'ch2', 'ch3', 'ch4', 'ch5'];

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const worldRef = useRef<WorldHandles | null>(null);
  const reduced = usePrefersReducedMotion();
  const [indexOpen, setIndexOpen] = useState(false);
  const active = useActiveSection(SECTION_IDS);

  /* Boot the world after first paint. Dynamic import keeps three.js
     out of the critical path so text shows immediately. */
  useEffect(() => {
    let disposed = false;
    let handles: WorldHandles | null = null;

    (async () => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const { createWorld } = await import('@/three/World');
      if (disposed) return;
      handles = createWorld(canvas, detectQuality());
      worldRef.current = handles;
      if (reduced) {
        handles.renderOnce();
      } else {
        handles.start();
      }
    })();

    return () => {
      disposed = true;
      handles?.dispose();
      worldRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* Reduced motion can flip at runtime. */
  useEffect(() => {
    const w = worldRef.current;
    if (!w) return;
    if (reduced) {
      w.stop();
      w.renderOnce();
    } else {
      w.start();
    }
  }, [reduced]);

  /* Scroll drives the camera and the CSS --p rail. */
  useScrollProgress(
    useCallback((p: number) => {
      worldRef.current?.setProgress(p);
      document.documentElement.style.setProperty('--p', p.toFixed(4));
    }, []),
  );

  /* Gentle pointer parallax; world clamps the response. */
  useEffect(() => {
    if (reduced) return;
    const onMove = (e: PointerEvent) => {
      const x = (e.clientX / window.innerWidth) * 2 - 1;
      const y = (e.clientY / window.innerHeight) * 2 - 1;
      worldRef.current?.setPointer(x, y);
    };
    window.addEventListener('pointermove', onMove, { passive: true });
    return () => window.removeEventListener('pointermove', onMove);
  }, [reduced]);

  const setWaypoint = useCallback((i: number) => worldRef.current?.setWaypoint(i), []);
  const setRing = useCallback((i: number) => worldRef.current?.setRing(i), []);

  return (
    <>
      <Boot reduced={reduced} onDone={() => undefined} />
      <canvas ref={canvasRef} className="world-canvas" aria-hidden="true" />
      <div className="veil" aria-hidden="true" />
      <span className="progress-bar" aria-hidden="true" />

      <TopBar onIndex={() => setIndexOpen(true)} />
      <RailNav active={active} />
      {indexOpen && <IndexOverlay onClose={() => setIndexOpen(false)} />}

      <main className="story">
        <Ch1 />
        <Ch2 onWaypoint={setWaypoint} />
        <Ch3 />
        <Ch4 onRing={setRing} />
        <Echoes />
        <Ch5 />
      </main>
    </>
  );
}
