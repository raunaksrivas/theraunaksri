/* ============================================================
   STORY.TS · The single source of truth for the narrative.
   Every word of career content here is preserved from the
   original portfolio. Only the framing is cinematic.
   ============================================================ */

export const IDENTITY = {
  name: 'Raunak Srivastava',
  role: 'Strategy Advisor · AI Strategist',
  tagline:
    'I build AI systems that eliminate inefficiency, automate operations, and free businesses to scale.',
  location: 'New Delhi, India',
  email: 'srivastava.raunak7@gmail.com',
  phone: '+91 9628198901',
  linkedin: 'https://linkedin.com/in/theraunaksri',
  github: 'https://github.com/theraunaksri',
  behance: 'https://www.behance.net/raunaksrivast3',
  cv: 'https://docs.google.com/document/d/18Dhqf_VB-Y01brK8Ob0H-twDVHnDLKSp/export?format=pdf',
};

export interface Chapter {
  id: string;
  code: string;
  title: string;
  monologue: string;
}

export const CHAPTERS: Chapter[] = [
  {
    id: 'ch1',
    code: 'CH.01 // THE SIGNAL',
    title: 'Every system begins with a signal.',
    monologue:
      'Before the pipelines, before the playbooks, there is a single idea moving through the dark, looking for a circuit to run on. I am Raunak Srivastava. I build AI systems that eliminate inefficiency, automate operations, and free businesses to scale. This is the world those systems come from. Keep scrolling. Follow the signal.',
  },
  {
    id: 'ch2',
    code: 'CH.02 // THE CIRCUIT',
    title: 'A signal is shaped by the path it travels.',
    monologue:
      'Seven stations across four years. From the billing halls of Indian Railways to a remote growth desk in the United States, every stop rerouted the current: new constraints, new stakeholders, new scale. Move down the line and watch what each station added.',
  },
  {
    id: 'ch3',
    code: 'CH.03 // THE PAYLOAD',
    title: 'What the signal carries is what counts.',
    monologue:
      'Strategy that never ships is static. These payloads made it to production: automation grids that erased manual work, audit systems that rewired search visibility, market entries signed into MOUs. Open the case files. Here, the numbers are part of the architecture.',
  },
  {
    id: 'ch4',
    code: 'CH.04 // THE ENGINE',
    title: 'Skill is a machine assembled over years.',
    monologue:
      'Underneath every launch is the engine room. Models and pipelines on one ring. Channels and funnels on another. Analytics and code keeping time. Strategy holding the frame. Reach for a ring and it answers.',
  },
  {
    id: 'ch5',
    code: 'CH.05 // THE HORIZON',
    title: 'The next system is not built yet.',
    monologue:
      'Somewhere ahead there is an operation drowning in manual work, a product still searching for its market, a founder who needs leverage more than headcount. That is where this signal is headed. If it sounds like yours, route it to me.',
  },
];

/* ---------- CH.01 · The three currents (services) ---------- */

export interface Current {
  code: string;
  title: string;
  body: string;
}

export const CURRENTS: Current[] = [
  {
    code: 'CURRENT.A',
    title: 'AI Automation Engineering',
    body:
      'I design and deploy end to end AI automation systems using n8n, Make.com, GPT-4, Claude, and WhatsApp API. From lead generation agents to enterprise workflow automation, I replace manual operations with intelligent pipelines.',
  },
  {
    code: 'CURRENT.B',
    title: 'Growth Marketing Systems',
    body:
      'Full funnel performance marketing across Google, YouTube, and LinkedIn Ads. HubSpot CRM automation, AI personalized cold outreach, SEO, AEO and GEO audits, and data driven campaign systems that reduce CAC and grow pipeline.',
  },
  {
    code: 'CURRENT.C',
    title: 'Strategy Consulting',
    body:
      'Enterprise client advisory, international market entry strategy, competitive intelligence, and stakeholder management. From board ready consulting decks to on ground project execution across energy, aerospace, and infrastructure sectors.',
  },
];

/* ---------- CH.02 · The seven stations (experience) ---------- */

export interface Station {
  id: string;
  index: string;
  role: string;
  company: string;
  date: string;
  location: string;
  points: string[];
}

export const STATIONS: Station[] = [
  {
    id: 'sta-railways',
    index: 'STA.01',
    role: 'Summer Intern',
    company: 'Indian Railways · Banaras Locomotive Works',
    date: 'Jun 2022 to Jul 2022',
    location: 'Varanasi, India',
    points: [
      'Mapped internal financial billing processes, identifying discrepancies that saved 15% in operational overhead.',
      'Delivered data backed recommendations yielding a 10% structural process efficiency improvement.',
    ],
  },
  {
    id: 'sta-technosapphire',
    index: 'STA.02',
    role: 'Trainee Software Developer',
    company: 'TechnoSapphire',
    date: 'Jan 2023 to Mar 2023',
    location: 'Noida, UP',
    points: [
      'Implemented critical UI and UX improvements that reduced the standard visitor bounce rate by 15%.',
      'Optimized front end performance, elevating user session engagement by 25%.',
    ],
  },
  {
    id: 'sta-bharatschool',
    index: 'STA.03',
    role: 'Trainee Software Developer',
    company: 'Bharat School E Learning',
    date: 'Apr 2024 to Jul 2024',
    location: 'India (Remote)',
    points: [
      'Engineered responsive React and Spring Boot interfaces showing interactive analytics and dashboards.',
      'Executed performance A/B testing on site funnels, delivering an immediate 30% boost in user product satisfaction.',
    ],
  },
  {
    id: 'sta-throughblack',
    index: 'STA.04',
    role: 'Strategic Engine: Marketing & Operations',
    company: 'Through Black (Danke Group)',
    date: 'Aug 2024 to Jan 2026',
    location: 'Vadodara, Gujarat',
    points: [
      'Led cross functional communication and strategic account strategy for enterprise brand acquisitions.',
      'Managed Southeast Asia market research and coordinated bilateral negotiations, resulting in a Vietnam market entry MOU.',
      'Curated the conceptual aerospace brand strategy and content alignment for the DroneX London exhibition.',
      'Orchestrated multi channel B2B campaigns for India\u2019s largest manufacturer of power transformers.',
      'Directed physical stall execution and visual signaling materials for over 10 enterprise clients at ELECRAMA.',
    ],
  },
  {
    id: 'sta-riya',
    index: 'STA.05',
    role: 'Project & Marketing Associate',
    company: 'Riya Advisories (Danke Group)',
    date: 'Jun 2025 to Aug 2025',
    location: 'Vadodara, Gujarat',
    points: [
      'Provided critical strategic consulting and research for enterprise clients inside the energy, pharma, and infra sectors.',
      'Coordinated cross functional communication between engineering supervisors, site contractors, and corporate managers.',
      'Maintained and structured clear EPC project documentation ensuring high level stakeholder compliance.',
    ],
  },
  {
    id: 'sta-freelance',
    index: 'STA.06',
    role: 'AI Automation Consultant',
    company: 'Freelance',
    date: '2025 to Present',
    location: 'Remote',
    points: [
      'Architected custom enterprise AI workflows, effectively eliminating the manual workload of 25 full time employees.',
      'Delivered an 80% operational cost reduction in targeted processes through scalable API connections.',
      'Engineered end to end no code automation pipelines to align cross system integrations.',
      'Liberated substantial executive bandwidth, allowing founders to focus on higher tier client and contract acquisition.',
    ],
  },
  {
    id: 'sta-opika',
    index: 'STA.07',
    role: 'Growth Marketing & AI Automation Specialist',
    company: 'Opika',
    date: 'Feb 2026 to Present',
    location: 'United States (Remote)',
    points: [
      'Designed and deployed AI automation pipelines that reduced manual operations by 40% across departments.',
      'Architected dynamic content workflows powered by GPT-4 and Claude to scale outbound communication.',
      'Optimized HubSpot CRM systems, enabling automated marketing triggers and clear pipeline scoring.',
      'Scaled full funnel paid media campaigns and integrated comprehensive GA4 and Amplitude analytics infrastructure.',
    ],
  },
];

/* ---------- CH.03 · Payload metrics (the environment data) ---------- */

export interface Metric {
  value: number;
  suffix: string;
  label: string;
}

export const METRICS: Metric[] = [
  { value: 80, suffix: '%', label: 'operational cost reduction through enterprise AI workflows' },
  { value: 25, suffix: '', label: 'full time workloads eliminated by one automation grid' },
  { value: 40, suffix: '%', label: 'manual operations reduced across departments at Opika' },
  { value: 30, suffix: '%', label: 'lift in user satisfaction from funnel A/B testing' },
  { value: 10, suffix: '+', label: 'enterprise clients delivered on site at ELECRAMA' },
  { value: 1, suffix: '', label: 'international MOU secured for Vietnam market entry' },
];

/* ---------- CH.03 · Case files ---------- */

export interface CaseFile {
  id: string;
  shelf: 'systems' | 'strategy';
  code: string;
  category: string;
  title: string;
  summary: string;
  dossier: { heading: string; body: string }[];
  tags: string[];
}

export const CASE_FILES: CaseFile[] = [
  /* ----- Shelf A · Systems built ----- */
  {
    id: 'case-enterprise-automation',
    shelf: 'systems',
    code: 'SYS.01',
    category: 'Enterprise Architecture',
    title: 'Enterprise AI Automation Workflow',
    summary:
      'A full enterprise grade automation grid that eliminated the workload of 25 full time employees and cut operational costs by 80%.',
    dossier: [
      {
        heading: 'Objective',
        body: 'Remove the manual operations layer that was consuming leadership attention and capping how large a contract the client could responsibly pursue.',
      },
      {
        heading: 'Build',
        body: 'Architected a full enterprise grade AI automation workflow spanning intake, processing, and delivery, connected through scalable API integrations and no code orchestration.',
      },
      {
        heading: 'Impact',
        body: 'Eliminated the workload of 25 full time employees and reduced operational costs by 80%, freeing the client\u2019s leadership to pursue and close significantly larger contracts.',
      },
    ],
    tags: ['n8n', 'Make.com', 'AI Agents', 'Business Process Automation', 'No Code'],
  },
  {
    id: 'case-agent-suite',
    shelf: 'systems',
    code: 'SYS.02',
    category: 'SMB Automation',
    title: 'AI Agent Suite: 3 Production Agents',
    summary:
      'Three production agents for Indian SMBs: Content Maker, Meeting Maker, and Query Replier, delivered WhatsApp native.',
    dossier: [
      {
        heading: 'Objective',
        body: 'Give small and mid sized Indian businesses working leverage through agents that live where they already operate: WhatsApp and their content channels.',
      },
      {
        heading: 'Build',
        body: 'Built three production AI agents: Content Maker for autonomous social content creation, Meeting Maker for AI meeting notes and follow up, and Query Replier, a WhatsApp integrated AI customer response system.',
      },
      {
        heading: 'Impact',
        body: 'Shipped as real production systems running on GPT-4 pipelines over n8n and Make.com, replacing repetitive communication work with automated, brand consistent output.',
      },
    ],
    tags: ['n8n', 'WhatsApp API', 'GPT-4', 'Make.com', 'SMB Automation'],
  },
  {
    id: 'case-seo-audit',
    shelf: 'systems',
    code: 'SYS.03',
    category: 'Full Funnel Organic',
    title: 'Multi Layer SEO / AEO / GEO Audit System',
    summary:
      'A 4 layer audit framework covering traditional SEO, answer engines, AI search, and generative engines, deployed across client sites.',
    dossier: [
      {
        heading: 'Objective',
        body: 'Make client websites visible not just to classic search crawlers but to the answer engines and generative AI systems that now mediate discovery.',
      },
      {
        heading: 'Build',
        body: 'Designed and deployed a 4 layer audit framework covering traditional SEO, Answer Engine Optimization (AEO), AI search optimization (AIO), and Generative Engine Optimization (GEO) across multiple client websites.',
      },
      {
        heading: 'Impact',
        body: 'Delivered scored reports with prioritized remediation roadmaps, turning an abstract visibility problem into a ranked engineering queue each client could execute.',
      },
    ],
    tags: ['SEO', 'AEO', 'GEO', 'AIO', 'Technical Audit', 'Content Strategy'],
  },
  {
    id: 'case-signal-tool',
    shelf: 'systems',
    code: 'SYS.04',
    category: 'B2B Competitive Intelligence',
    title: 'SIGNAL: LinkedIn Content Intelligence',
    summary:
      'A LinkedIn analytics and intelligence tool for post performance, competitive benchmarking, and content strategy.',
    dossier: [
      {
        heading: 'Objective',
        body: 'Give B2B brands an instrument panel for LinkedIn: what is working, what competitors are doing, and where the content strategy should move next.',
      },
      {
        heading: 'Build',
        body: 'Designed and prototyped SIGNAL, a LinkedIn content analytics and intelligence tool for tracking post performance, competitive benchmarking, and content strategy optimization.',
      },
      {
        heading: 'Impact',
        body: 'Converted scattered post metrics into comparable intelligence, letting brands benchmark against competitors instead of guessing from their own feed.',
      },
    ],
    tags: ['LinkedIn', 'Content Analytics', 'Competitive Intelligence', 'B2B'],
  },
  {
    id: 'case-bharatpulse',
    shelf: 'systems',
    code: 'SYS.05',
    category: 'Autonomous Agents',
    title: 'BharatPulse: Autonomous AI News',
    summary:
      'A fully autonomous Twitter/X account covering India centric infrastructure, economy, startup, policy, and tech news.',
    dossier: [
      {
        heading: 'Objective',
        body: 'Prove that an editorial product can run end to end without a newsroom: sourcing, writing, branding, and publishing handled by pipelines.',
      },
      {
        heading: 'Build',
        body: 'Built an AI powered autonomous Twitter/X account for India centric news covering infrastructure, economy, startups, policy, and tech, with automated content pipelines, branded identity, and scheduled posting systems.',
      },
      {
        heading: 'Impact',
        body: 'An always on publication that maintains voice and cadence without manual intervention, demonstrating full stack content automation in production.',
      },
    ],
    tags: ['AI Automation', 'GPT-4', 'Twitter/X', 'Content Pipeline', 'BharatPulse'],
  },
  {
    id: 'case-email-agent',
    shelf: 'systems',
    code: 'SYS.06',
    category: 'Productivity Agent',
    title: 'AI Email Tracking & Triage Agent',
    summary:
      'A Gmail integrated n8n agent for reply drafting, thread summarization, priority flagging, and inbox triage.',
    dossier: [
      {
        heading: 'Objective',
        body: 'Take the inbox off the critical path. Email should be processed by a system and only escalate to a human when judgment is actually required.',
      },
      {
        heading: 'Build',
        body: 'Engineered a Gmail integrated n8n agent capable of automated reply drafting, email thread summarization, priority flagging, and inbox triage.',
      },
      {
        heading: 'Impact',
        body: 'Reduced email management time significantly, converting a daily attention tax into a supervised background process.',
      },
    ],
    tags: ['Gmail', 'n8n', 'AI Agent', 'Email Automation', 'Productivity'],
  },

  /* ----- Shelf B · Strategy deployed ----- */
  {
    id: 'case-uav',
    shelf: 'strategy',
    code: 'STR.01',
    category: 'Market Entry Strategy',
    title: 'UAV International Market Entry',
    summary:
      'UK and Europe entry strategy for a Tier 1 UAV manufacturer, built on risk signaling and trust architecture.',
    dossier: [
      {
        heading: 'Objective',
        body: 'Establish Tier 1 credibility for a domestic UAV leader entering the high risk UK aerospace ecosystem.',
      },
      {
        heading: 'Challenge',
        body: 'No established brand recognition among Western aerospace buyers. Success depended on not failing publicly in a credibility driven industry.',
      },
      {
        heading: 'Strategy',
        body: 'Prioritized belonging over promotion and clarity over complexity. Designed a procurement safe narrative and a structured signaling strategy across merchandise and brochures to reduce perceived supplier risk at DroneX London.',
      },
      {
        heading: 'Outcome',
        body: 'Avoided credibility failure, achieved higher quality stakeholder conversations, and enabled structured post event follow up recall.',
      },
    ],
    tags: ['Risk Signaling', 'Aerospace GTM', 'Communication Design'],
  },
  {
    id: 'case-vietnam',
    shelf: 'strategy',
    code: 'STR.02',
    category: 'Market Entry Consulting',
    title: 'Vietnam Market Entry & Channel Strategy',
    summary:
      'The strategic roadmap for Southeast Asian industrial expansion, closed with a formalized MOU.',
    dossier: [
      {
        heading: 'Client & Industry',
        body: 'An industrial manufacturing firm expanding to Southeast Asia.',
      },
      {
        heading: 'Challenge',
        body: 'Establish a credible market presence in Vietnam with zero existing regional footprint or local network, while navigating complex regulatory landscapes and fragmented distribution channels.',
      },
      {
        heading: 'Approach',
        body: 'Conducted primary market research on Vietnam\u2019s industrial infrastructure and retail environment. Managed end to end strategic partnership negotiations, leading to a formalized MOU for regional expansion.',
      },
      {
        heading: 'Impact',
        body: 'Secured a foundational regional footprint and established high level stakeholder relationships for long term growth in the Southeast Asian market.',
      },
    ],
    tags: ['International BD', 'Negotiation Strategy', 'Market Entry'],
  },
  {
    id: 'case-swiggy',
    shelf: 'strategy',
    code: 'STR.03',
    category: 'Product Strategy & Growth',
    title: 'Increasing AOV at Swiggy Instamart',
    summary:
      'Bridging the \u20B9420 to \u20B9607 AOV gap through psychological pricing and optimized upsell logic.',
    dossier: [
      {
        heading: 'Objective',
        body: 'Increase the Average Order Value from \u20B9420 toward the industry leading \u20B9607 benchmark.',
      },
      {
        heading: 'Problem Space',
        body: 'Only 25% of the 9 million registered users were active paying customers, frequently purchasing low value items.',
      },
      {
        heading: 'Strategic Recommendations',
        body: 'Introduced limited period sale banners with countdown timers and FOMO driven notifications. Pivoted from percentage discounts to value based framing such as Save \u20B9100 on every \u20B91000. Developed upgrade popups suggesting larger quantities during the add to cart flow. Streamlined customer support with immediate refunds and order approval to drive repeat, high value frequency.',
      },
      {
        heading: 'Target Impact',
        body: 'Projected 15% increase in AOV within a 6 month roadmap.',
      },
    ],
    tags: ['Product Growth', 'Upsell Strategy', 'A/B Testing Logic'],
  },
  {
    id: 'case-lenskart',
    shelf: 'strategy',
    code: 'STR.04',
    category: 'GTM Strategy',
    title: 'Lenskart Retail Expansion Strategy',
    summary:
      'Regional footprint optimization and retail operations roadmap for physical store scaling.',
    dossier: [
      {
        heading: 'Objective',
        body: 'Develop a data driven framework for selecting high conversion retail locations for physical expansion.',
      },
      {
        heading: 'Approach',
        body: 'Analyzed online search intent and demographic data to cluster high potential zones. Standardized retail SOPs to ensure brand consistency across new franchise and owned outlets.',
      },
      {
        heading: 'Outcome',
        body: 'Accelerated physical store deployment with higher Day 1 footfall and faster operational breakeven.',
      },
    ],
    tags: ['Retail Ops', 'Regional GTM', 'Site Optimization'],
  },
];

/* ---------- CH.04 · The four rings (skills) ---------- */

export interface SkillRing {
  code: string;
  title: string;
  items: string[];
}

export const SKILL_RINGS: SkillRing[] = [
  {
    code: 'RING.01',
    title: 'AI & Automation',
    items: [
      'n8n', 'Make.com', 'GPT-4', 'Claude', 'Gemini', 'Perplexity',
      'WhatsApp API', 'Prompt Engineering', 'AI Agents', 'Vibe Coding', 'Zapier',
    ],
  },
  {
    code: 'RING.02',
    title: 'Marketing & GTM',
    items: [
      'HubSpot', 'Instantly', 'Heyreach', 'Google Ads', 'YouTube Ads', 'LinkedIn Ads',
      'SEO/AEO/GEO', 'Content Strategy', 'A/B Testing', 'Canva', 'Loom', 'Riverside.fm',
    ],
  },
  {
    code: 'RING.03',
    title: 'Analytics & Development',
    items: [
      'Google Analytics 4', 'Microsoft Clarity', 'Amplitude', 'Looker Studio', 'SQL',
      'React', 'HTML/CSS', 'JavaScript', 'Python', 'Spring Boot', 'Node.js', 'Figma', 'Adobe XD',
    ],
  },
  {
    code: 'RING.04',
    title: 'Strategy',
    items: [
      'GTM Strategy', 'Brand Strategy', 'Competitive Intelligence', 'Market Entry',
      'Stakeholder Management', 'Pipeline Management', 'Enterprise Sales',
      'C Level Communication', 'Digital Transformation',
    ],
  },
];

/* ---------- CH.04 · Foundations (credentials) ---------- */

export interface Foundation {
  badge: string;
  title: string;
  institution: string;
  year: string;
  extras?: string[];
}

export const FOUNDATIONS: Foundation[] = [
  {
    badge: 'McK',
    title: 'McKinsey Forward Program Alumni',
    institution: 'McKinsey & Company',
    year: 'Completed 2025',
  },
  {
    badge: 'ASP',
    title: 'Aspire Leaders Program',
    institution: 'Aspire Institute (Founded at Harvard University)',
    year: 'Cohort 5 · 2025',
  },
  {
    badge: 'KNIT',
    title: 'B.Tech: Information Technology',
    institution: 'KNIT, Sultanpur',
    year: '2019 to 2023',
  },
  {
    badge: 'CRT',
    title: 'Professional Industry Foundations',
    institution: 'Global Multi Domain Standards',
    year: '',
    extras: ['Google Digital Marketing', 'AWS Fundamentals', 'Cloud Computing', 'Software Testing'],
  },
];

/* ---------- Interlude · Echoes (testimonials) ---------- */

export interface Echo {
  quote: string[];
  author: string;
  title: string;
  relation: string;
}

export const ECHOES: Echo[] = [
  {
    quote: [
      'There are minds that remind you why intelligence matters: minds that chase the new, the different, the unapologetically original.',
      'Raunak is one of them. A thinker who brings rare ideas to the table; honest in execution; grounded in respect and learning at the workplace.',
      'He is a brilliant addition to any team that dares to be different.',
      'Keep chasing the unknown! Keep rising!',
    ],
    author: 'Siddhartha \u0938\u093F\u0926\u094D\u0927\u093E\u0930\u094D\u0925',
    title: '\u092D\u093E\u0930\u0924 . Branding . Energy . A & D . Planet',
    relation: 'December 12, 2025 · Siddhartha managed Raunak directly',
  },
  {
    quote: [
      'An exceptional strategist who translates complex AI technology into immediate business dividends. Raunak\u2019s automation pipelines didn\u2019t just optimize our operational run rate, they fundamentally revolutionized our approach to enterprise sales and market speed.',
      'If your organization wants to bypass standard agency overhead and build real automated leverage, he is the executive you partner with.',
    ],
    author: 'Enterprise & SMB Clients',
    title: 'SaaS, Energy & Infrastructure Sectors',
    relation: 'Direct Consultation Feedback Summary',
  },
];

/* ---------- CH.05 · The horizon ---------- */

export const HORIZON = {
  openTo:
    'Open to AI automation consulting, growth marketing strategy, technical PM roles, and founding team opportunities.',
  status: ['STATUS: OPEN_FOR_ENGAGEMENTS', 'LOC: NEW_DELHI_IN', 'TYPICAL_RESPONSE: 24H'],
};

export const BOOT_LINES = [
  '> INITIALIZING SIGNAL',
  '> ROUTING: NEW_DELHI / 28.61N 77.20E',
  '> LOADING WORLD MODULES',
  '> SIGNAL ACQUIRED',
];
