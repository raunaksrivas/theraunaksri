import { CHAPTERS } from '@/content/story';

/* The signature element: a vertical circuit trace mirroring the
   journey. The pulse dot position is driven by the global --p
   custom property, so it costs nothing per frame in React. */
export default function RailNav({ active }: { active: string }) {
  return (
    <nav className="rail" aria-label="Chapters">
      <div className="rail-track">
        <span className="rail-fill" aria-hidden="true" />
        <span className="rail-pulse" aria-hidden="true" />
        <div className="rail-nodes">
          {CHAPTERS.map((ch) => (
            <a
              key={ch.id}
              href={`#${ch.id}`}
              className="rail-node"
              aria-current={active === ch.id ? 'true' : undefined}
              aria-label={ch.code}
            >
              <span className="tip">{ch.code}</span>
            </a>
          ))}
        </div>
      </div>
    </nav>
  );
}
