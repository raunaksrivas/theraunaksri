import { ECHOES } from '@/content/story';
import { useReveal } from '@/lib/hooks';

export default function Echoes() {
  const ref = useReveal<HTMLDivElement>(0.12);
  return (
    <section id="echoes" className="chapter echoes" aria-label="Echoes: what others say">
      <div className="chapter-inner" style={{ width: '100%' }}>
        <div className="echo-grid reveal" ref={ref}>
          {ECHOES.map((e, i) => (
            <article key={e.author} className="echo" style={{ ['--d' as string]: `${i * 0.1}s` }}>
              <p className="echo-mark">Transmission {String(i + 1).padStart(2, '0')} · Intercepted</p>
              <blockquote>
                {e.quote.map((q) => (
                  <p key={q.slice(0, 24)}>{q}</p>
                ))}
              </blockquote>
              <footer>
                <p className="author">{e.author}</p>
                <p className="title">{e.title}</p>
                <p className="relation">{e.relation}</p>
              </footer>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
