import { useEffect, useRef } from 'react';
import type { CaseFile } from '@/content/story';

export default function CaseDossier({ file, onClose }: { file: CaseFile; onClose: () => void }) {
  const closeBtn = useRef<HTMLButtonElement | null>(null);

  useEffect(() => {
    closeBtn.current?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', onKey);
      document.body.style.overflow = prev;
    };
  }, [onClose]);

  return (
    <div
      className="dossier-backdrop"
      role="dialog"
      aria-modal="true"
      aria-label={`Case file: ${file.title}`}
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <article className="dossier">
        <button ref={closeBtn} className="dossier-close" onClick={onClose}>
          Close · Esc
        </button>
        <div className="case-top">
          <span className="code">{file.code}</span>
          <span className="cat">{file.category}</span>
        </div>
        <h2>{file.title}</h2>
        {file.dossier.map((sec) => (
          <section key={sec.heading} className="dossier-section">
            <h4>{sec.heading}</h4>
            <p>{sec.body}</p>
          </section>
        ))}
        <div className="tags">
          {file.tags.map((t) => (
            <span key={t} className="tag">
              {t}
            </span>
          ))}
        </div>
      </article>
    </div>
  );
}
