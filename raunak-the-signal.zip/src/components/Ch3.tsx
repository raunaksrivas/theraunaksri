import { useEffect, useRef, useState } from 'react';
import { CASE_FILES, CHAPTERS, METRICS } from '@/content/story';
import type { CaseFile } from '@/content/story';
import { useReveal, usePrefersReducedMotion } from '@/lib/hooks';
import CaseDossier from './CaseDossier';

export default function Ch3() {
  const head = useReveal<HTMLDivElement>();
  const metricsRef = useReveal<HTMLDivElement>(0.2);
  const [open, setOpen] = useState<CaseFile | null>(null);
  const ch = CHAPTERS[2];

  const systems = CASE_FILES.filter((c) => c.shelf === 'systems');
  const strategy = CASE_FILES.filter((c) => c.shelf === 'strategy');

  return (
    <section id="ch3" className="chapter ch3" aria-label={ch.code}>
      <div className="chapter-inner">
        <div className="ch3-head reveal" ref={head}>
          <span className="eyebrow">{ch.code}</span>
          <h2 className="chapter-title">
            What the signal <span className="accent">carries</span> is what counts.
          </h2>
          <p className="monologue">{ch.monologue}</p>
        </div>

        <div className="metrics reveal" ref={metricsRef}>
          {METRICS.map((m) => (
            <MetricCell key={m.label} value={m.value} suffix={m.suffix} label={m.label} />
          ))}
        </div>

        <Shelf
          label="Shelf A · Systems shipped"
          files={systems}
          onOpen={setOpen}
        />
        <Shelf
          label="Shelf B · Strategy delivered"
          files={strategy}
          strategy
          onOpen={setOpen}
        />
      </div>

      {open && <CaseDossier file={open} onClose={() => setOpen(null)} />}
    </section>
  );
}

function Shelf({
  label,
  files,
  strategy,
  onOpen,
}: {
  label: string;
  files: CaseFile[];
  strategy?: boolean;
  onOpen: (f: CaseFile) => void;
}) {
  const ref = useReveal<HTMLDivElement>(0.06);
  return (
    <>
      <p className="shelf-label">{label}</p>
      <div className={`case-grid reveal${strategy ? ' strategy' : ''}`} ref={ref}>
        {files.map((f, i) => (
          <button
            key={f.id}
            className="case-card"
            style={{ ['--d' as string]: `${(i % 3) * 0.07}s` }}
            onClick={() => onOpen(f)}
            aria-haspopup="dialog"
          >
            <span className="case-top">
              <span className="code">{f.code}</span>
              <span className="cat">{f.category}</span>
            </span>
            <h3>{f.title}</h3>
            <p className="summary">{f.summary}</p>
            <span className="case-open">Open file</span>
          </button>
        ))}
      </div>
    </>
  );
}

/* Counts up once when scrolled into view. Honest numbers, no
   easing tricks: a fixed 1.1s ramp with an outExpo curve. */
function MetricCell({ value, suffix, label }: { value: number; suffix: string; label: string }) {
  const reduced = usePrefersReducedMotion();
  const ref = useRef<HTMLDivElement | null>(null);
  const [display, setDisplay] = useState(reduced ? value : 0);

  useEffect(() => {
    if (reduced) {
      setDisplay(value);
      return;
    }
    const el = ref.current;
    if (!el || typeof IntersectionObserver === 'undefined') {
      setDisplay(value);
      return;
    }
    let raf = 0;
    const io = new IntersectionObserver(
      ([entry]) => {
        if (!entry.isIntersecting) return;
        io.disconnect();
        const t0 = performance.now();
        const dur = 1100;
        const tick = (t: number) => {
          const k = Math.min(1, (t - t0) / dur);
          const eased = 1 - Math.pow(2, -10 * k);
          setDisplay(Math.round(value * eased));
          if (k < 1) raf = requestAnimationFrame(tick);
          else setDisplay(value);
        };
        raf = requestAnimationFrame(tick);
      },
      { threshold: 0.4 },
    );
    io.observe(el);
    return () => {
      io.disconnect();
      cancelAnimationFrame(raf);
    };
  }, [value, reduced]);

  return (
    <div className="metric" ref={ref}>
      <p className="metric-value">
        {display}
        {suffix}
      </p>
      <p className="metric-label">{label}</p>
    </div>
  );
}
