import { IDENTITY } from '@/content/story';

export default function TopBar({ onIndex }: { onIndex: () => void }) {
  return (
    <header className="topbar">
      <a
        className="monogram"
        href="#ch1"
        aria-label="Back to the beginning"
        onClick={(e) => {
          e.preventDefault();
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
      >
        RS<span className="tick">_</span>
      </a>
      <nav className="topbar-actions" aria-label="Primary">
        <button className="chip" onClick={onIndex} aria-haspopup="dialog">
          Index
        </button>
        <a
          className="chip hide-sm"
          href={IDENTITY.cv}
          target="_blank"
          rel="noopener noreferrer"
        >
          CV
        </a>
        <a className="chip solid" href="#ch5">
          Contact
        </a>
      </nav>
    </header>
  );
}
