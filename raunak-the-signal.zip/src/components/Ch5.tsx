import { useState } from 'react';
import { CHAPTERS, HORIZON, IDENTITY } from '@/content/story';
import { useReveal } from '@/lib/hooks';

export default function Ch5() {
  const ref = useReveal<HTMLDivElement>();
  const [copied, setCopied] = useState(false);
  const ch = CHAPTERS[4];

  const copyEmail = async () => {
    try {
      await navigator.clipboard.writeText(IDENTITY.email);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2400);
    } catch {
      window.location.href = `mailto:${IDENTITY.email}`;
    }
  };

  return (
    <section id="ch5" className="chapter ch5" aria-label={ch.code}>
      <div className="chapter-inner" style={{ display: 'flex', flexDirection: 'column', flex: 1 }}>
        <div className="ch5-stage reveal" ref={ref}>
          <span className="eyebrow">{ch.code}</span>
          <h2 className="chapter-title">
            The next system is <span className="accent">not built yet.</span>
          </h2>
          <p className="monologue">{ch.monologue}</p>
          <p className="horizon-open">{HORIZON.openTo}</p>

          <div className="actions">
            <a className="action primary" href={`mailto:${IDENTITY.email}`}>
              Send the brief
            </a>
            <button className="action" onClick={copyEmail}>
              Copy email
            </button>
            <a
              className="action"
              href={IDENTITY.linkedin}
              target="_blank"
              rel="noopener noreferrer"
            >
              LinkedIn
            </a>
            <a className="action" href={IDENTITY.cv} target="_blank" rel="noopener noreferrer">
              Download CV
            </a>
          </div>
          <p className="copied-note" role="status">
            {copied ? `> ${IDENTITY.email} COPIED TO CLIPBOARD` : '\u00A0'}
          </p>

          <div className="status-readout" aria-label="Status">
            {HORIZON.status.map((s, i) => (
              <span key={s}>
                {i === 0 && <span className="dot" aria-hidden="true" />}
                {s}
              </span>
            ))}
          </div>
        </div>

        <footer className="footer">
          <span>
            {'\u00A9'} {new Date().getFullYear()} {IDENTITY.name} · Built as one continuous signal
          </span>
          <span>
            <a href={IDENTITY.github} target="_blank" rel="noopener noreferrer">
              GitHub
            </a>
            {'  ·  '}
            <a href={IDENTITY.behance} target="_blank" rel="noopener noreferrer">
              Behance
            </a>
            {'  ·  '}
            <a href="/classic.html">Classic version</a>
          </span>
        </footer>
      </div>
    </section>
  );
}
