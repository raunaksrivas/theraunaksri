import { useEffect, useRef } from 'react';
import { CHAPTERS } from '@/content/story';

export default function IndexOverlay({ onClose }: { onClose: () => void }) {
  const firstLink = useRef<HTMLButtonElement | null>(null);

  useEffect(() => {
    firstLink.current?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', onKey);
      document.body.style.overflow = prev;
    };
  }, [onClose]);

  const go = (id: string) => {
    onClose();
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div
      className="index-backdrop"
      role="dialog"
      aria-modal="true"
      aria-label="Chapter index"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="index-panel">
        <div className="index-head">
          <span className="eyebrow">Index</span>
          <button className="chip" onClick={onClose}>
            Close · Esc
          </button>
        </div>
        <ul className="index-list">
          {CHAPTERS.map((ch, i) => (
            <li key={ch.id}>
              <button
                ref={i === 0 ? firstLink : undefined}
                className="index-link"
                onClick={() => go(ch.id)}
              >
                <span className="num">{String(i + 1).padStart(2, '0')}</span>
                <span className="name">{ch.code.split('// ')[1]}</span>
              </button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
