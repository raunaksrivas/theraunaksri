import { useEffect, useRef } from 'react';
import { CHAPTERS, STATIONS } from '@/content/story';
import { useReveal } from '@/lib/hooks';

/* Each station card reports itself to the world when it crosses
   midscreen, so the 3D trace and pulse stay in lockstep with the
   reading position. */
export default function Ch2({ onWaypoint }: { onWaypoint: (i: number) => void }) {
  const head = useReveal<HTMLDivElement>();
  const listRef = useRef<HTMLDivElement | null>(null);
  const ch = CHAPTERS[1];

  useEffect(() => {
    const root = listRef.current;
    if (!root || typeof IntersectionObserver === 'undefined') return;
    const cards = Array.from(root.querySelectorAll<HTMLElement>('[data-station]'));
    const io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting) {
            const idx = Number((e.target as HTMLElement).dataset.station);
            onWaypoint(idx);
          }
        }
      },
      { rootMargin: '-42% 0px -42% 0px', threshold: 0 },
    );
    cards.forEach((c) => io.observe(c));
    return () => io.disconnect();
  }, [onWaypoint]);

  return (
    <section id="ch2" className="chapter ch2" aria-label={ch.code}>
      <div className="chapter-inner">
        <div className="ch2-head reveal" ref={head}>
          <span className="eyebrow">{ch.code}</span>
          <h2 className="chapter-title">
            A signal is shaped by the <span className="accent">path</span> it travels.
          </h2>
          <p className="monologue">{ch.monologue}</p>
        </div>

        <div className="stations" ref={listRef}>
          {STATIONS.map((s, i) => (
            <StationCard key={s.id} index={i} station={s} />
          ))}
        </div>
      </div>
    </section>
  );
}

function StationCard({ station, index }: { station: (typeof STATIONS)[number]; index: number }) {
  const ref = useReveal<HTMLDivElement>(0.12);
  return (
    <div className="station" data-station={index}>
      <article className="station-card reveal" ref={ref}>
        <p className="station-index">{station.index}</p>
        <h3 className="station-role">{station.role}</h3>
        <p className="station-company">{station.company}</p>
        <p className="station-meta">
          {station.date} · {station.location}
        </p>
        <ul className="station-points">
          {station.points.map((pt) => (
            <li key={pt}>{pt}</li>
          ))}
        </ul>
      </article>
    </div>
  );
}
