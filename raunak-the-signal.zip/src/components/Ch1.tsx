import { CHAPTERS, CURRENTS, IDENTITY } from '@/content/story';
import { useReveal } from '@/lib/hooks';

export default function Ch1() {
  const head = useReveal<HTMLDivElement>();
  const grid = useReveal<HTMLDivElement>(0.1);
  const ch = CHAPTERS[0];

  return (
    <section id="ch1" className="chapter ch1" aria-label={ch.code}>
      <div className="chapter-inner">
        <div className="ch1-stage reveal" ref={head}>
          <p className="ch1-name">{IDENTITY.name} · {IDENTITY.role}</p>
          <span className="eyebrow">{ch.code}</span>
          <h1 className="chapter-title ch1-title">
            Every system begins with a <span className="accent">signal.</span>
          </h1>
          <p className="monologue">{ch.monologue}</p>
          <div className="scroll-cue" aria-hidden="true">
            <span className="beam" />
            <span>Scroll to descend</span>
          </div>
        </div>

        <div className="currents reveal" ref={grid}>
          {CURRENTS.map((c, i) => (
            <article key={c.code} className="card" style={{ ['--d' as string]: `${i * 0.08}s` }}>
              <p className="card-code">{c.code}</p>
              <h3>{c.title}</h3>
              <p>{c.body}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
