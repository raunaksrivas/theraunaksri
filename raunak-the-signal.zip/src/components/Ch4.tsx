import { useEffect, useRef } from 'react';
import { CHAPTERS, FOUNDATIONS, SKILL_RINGS } from '@/content/story';
import { useReveal } from '@/lib/hooks';

/* Hovering, focusing, or scrolling a ring panel into the middle of
   the screen lights the matching ring in the 3D engine behind it. */
export default function Ch4({ onRing }: { onRing: (i: number) => void }) {
  const head = useReveal<HTMLDivElement>();
  const grid = useReveal<HTMLDivElement>(0.08);
  const found = useReveal<HTMLDivElement>(0.08);
  const listRef = useRef<HTMLDivElement | null>(null);
  const ch = CHAPTERS[3];

  useEffect(() => {
    const root = listRef.current;
    if (!root || typeof IntersectionObserver === 'undefined') return;
    const panels = Array.from(root.querySelectorAll<HTMLElement>('[data-ring]'));
    const io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting) onRing(Number((e.target as HTMLElement).dataset.ring));
        }
      },
      { rootMargin: '-38% 0px -38% 0px', threshold: 0 },
    );
    panels.forEach((p) => io.observe(p));
    return () => io.disconnect();
  }, [onRing]);

  return (
    <section id="ch4" className="chapter ch4" aria-label={ch.code}>
      <div className="chapter-inner">
        <div className="ch4-head reveal" ref={head}>
          <span className="eyebrow">{ch.code}</span>
          <h2 className="chapter-title">
            Skill is a <span className="accent">machine</span> assembled over years.
          </h2>
          <p className="monologue">{ch.monologue}</p>
        </div>

        <div className="rings reveal" ref={grid}>
          <div ref={listRef} style={{ display: 'contents' }}>
            {SKILL_RINGS.map((ring, i) => (
              <article
                key={ring.code}
                className="ring-panel"
                data-ring={i}
                tabIndex={0}
                onMouseEnter={() => onRing(i)}
                onFocus={() => onRing(i)}
                style={{ ['--d' as string]: `${i * 0.07}s` }}
              >
                <div className="ring-top">
                  <span className="ring-code">{ring.code}</span>
                  <span className="ring-count">{String(ring.items.length).padStart(2, '0')} NODES</span>
                </div>
                <h3>{ring.title}</h3>
                <div className="tags">
                  {ring.items.map((item) => (
                    <span key={item} className="tag">
                      {item}
                    </span>
                  ))}
                </div>
              </article>
            ))}
          </div>
        </div>

        <div className="foundations reveal" ref={found}>
          {FOUNDATIONS.map((f) => (
            <article key={f.title} className="foundation">
              <span className="foundation-badge">{f.badge}</span>
              <h4>{f.title}</h4>
              <p className="inst">{f.institution}</p>
              {f.extras && <p className="inst">{f.extras.join(' · ')}</p>}
              {f.year && <p className="year">{f.year}</p>}
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
