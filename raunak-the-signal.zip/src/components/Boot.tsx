import { useEffect, useState } from 'react';
import { BOOT_LINES } from '@/content/story';

/* A short system boot: four mono lines and a fill bar, then the
   world fades in. Skipped entirely under reduced motion. */
export default function Boot({ reduced, onDone }: { reduced: boolean; onDone: () => void }) {
  const [done, setDone] = useState(reduced);

  useEffect(() => {
    if (reduced) {
      onDone();
      return;
    }
    const t = window.setTimeout(() => {
      setDone(true);
      onDone();
    }, 1500);
    return () => window.clearTimeout(t);
  }, [reduced, onDone]);

  if (reduced) return null;

  return (
    <div className={`boot${done ? ' done' : ''}`} aria-hidden={done}>
      <div className="boot-lines" role="status" aria-label="Loading">
        {BOOT_LINES.map((line, i) => (
          <span key={line} className="boot-line" style={{ animationDelay: `${i * 0.22}s` }}>
            {line}
          </span>
        ))}
        <span className="boot-bar" />
      </div>
    </div>
  );
}
